#include <bits/stdc++.h>
using namespace std;
void Assign(int a1[], int a2[], int n)
{
    for (int i = 0; i < n; i++)
        a1[i] = a2[i];
}
void display(int n, int Process_Size[], int allocate[])
{
    cout << "\nProcess No.\t Process Size\tBlock No.\n";
    for (int i = 0; i < n; i++)
    {
        cout << " " << i + 1 << "\t\t" << Process_Size[i] << "\t\t";
        if (allocate[i] != -1)
            cout << allocate[i] + 1;
        else
            cout << "Not Allocated";
        cout << endl;
    }
}
void FirstFit(int B[], int n, int P[], int m)
{
    int Block_Size[n], Process_Size[m];
    Assign(Block_Size, B, n);
    Assign(Process_Size, P, m);
    int allocate[n];
    memset(allocate, -1, sizeof(allocate));
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (Block_Size[j] >= Process_Size[i])
            {
                allocate[i] = j;
                Block_Size[j] -= Process_Size[i];
                break;
            }
        }
    }
    display(m, Process_Size, allocate);
}
void NextFit(int B[], int n, int P[], int m)
{
    int Block_Size[n], Process_Size[m];
    Assign(Block_Size, B, n);
    Assign(Process_Size, P, m);
    int allocate[n], j = 0;
    memset(allocate, -1, sizeof(allocate));
    for (int i = 0; i < m; i++)
    {
        int count = 0;
        while (count < n)
        {
            if (Block_Size[j] >= Process_Size[i])
            {
                allocate[i] = j;
                Block_Size[j] -= Process_Size[i];
                break;
            }
            j = (j + 1) % m;
            count++;
        }
    }
    display(m, Process_Size, allocate);
}
void BestFit(int B[], int n, int P[], int m)
{
    int Block_Size[n], Process_Size[m];
    Assign(Block_Size, B, n);
    Assign(Process_Size, P, m);
    int allocate[n];
    memset(allocate, -1, sizeof(allocate));
    for (int i = 0; i < m; i++)
    {
        int idx = -1;
        for (int j = 0; j < n; j++)
        {
            if (Block_Size[j] >= Process_Size[i])
            {
                if (idx == -1)
                    idx = j;
                else if (Block_Size[j] < Block_Size[idx])
                    idx = j;
            }
        }
        if (idx != -1)
        {
            allocate[i] = idx;
            Block_Size[idx] -= Process_Size[i];
        }
    }
    display(m, Process_Size, allocate);
}
void WorstFit(int B[], int n, int P[], int m)
{
    int Block_Size[n], Process_Size[m];
    Assign(Block_Size, B, n);
    Assign(Process_Size, P, m);
    int allocate[n];
    memset(allocate, -1, sizeof(allocate));
    for (int i = 0; i < m; i++)
    {
        int idx = -1;
        for (int j = 0; j < n; j++)
        {
            if (Block_Size[j] >= Process_Size[i])
            {
                if (idx == -1)
                    idx = j;
                else if (Block_Size[j] >= Block_Size[idx])
                    idx = j;
            }
        }
        if (idx != -1)
        {
            allocate[i] = idx;
            Block_Size[idx] -= Process_Size[i];
        }
    }
    display(m, Process_Size, allocate);
}
int main()
{
    bool loop = true;
    int n, m;

    int Block_Size[] = {100, 500, 200, 300, 600};

    int Process_Size[] = {212, 417, 112, 426};

    while (loop)
    {
        cout << "1. Best Fit\n";
        cout << "2. Worst Fit\n";
        cout << "3. First Fit\n";
        cout << "4. Next Fit\n";
        cout << "5. Exit\n";
        cout << "Enter Choice: \n";
        int choice;
        cin >> choice;
        switch (choice)
        {
        case 1:
            BestFit(Block_Size, 5, Process_Size, 4);
            break;
        case 2:
            WorstFit(Block_Size, 5, Process_Size, 4);
            break;
        case 3:
            FirstFit(Block_Size, 5, Process_Size, 4);
            break;
        case 4:
            NextFit(Block_Size, 5, Process_Size, 4);
            break;
        case 5:
            loop = false;
            break;
        default:
            cout << "Something went wrong";
            break;
        }
    }
    return 0;
}
